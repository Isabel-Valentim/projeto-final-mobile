import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Importe as telas
import LoginScreen from './assets/LoginScreen';
import SignupScreen from './assets/SignupScreen';
import HomeScreen from './assets/HomeScreen';
import { TaskProvider } from './assets/TaskContext';
import { EventProvider } from './assets/EventContext';
import MainTabs from './assets/HomeScreen'; // Importe a navegação com as abas (TaskScreen e CalendarScreen)

const Stack = createStackNavigator();

const AuthStack = () => {
  return ( 
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Cadastro" component={SignupScreen} />
    </Stack.Navigator>
  );
};

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false); // Define o estado de autenticação

  return (
    <TaskProvider>
      <EventProvider>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {isAuthenticated ? (
              <Stack.Screen name="Main" component={MainTabs} />
            ) : (
              <Stack.Screen name="Auth" component={AuthStack} />
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </EventProvider>
    </TaskProvider>
  );
};

export default App;
