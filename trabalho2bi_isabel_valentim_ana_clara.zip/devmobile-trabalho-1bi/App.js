import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/Ionicons';

// Importe as telas
import LoginScreen from './assets/LoginScreen';
import SignupScreen from './assets/SignupScreen';
import TaskScreen from './assets/TaskScreen';
import CalendarScreen from './assets/CalendarScreen'; // Tela do calendário
import { TaskProvider } from './assets/TaskContext';
import { EventProvider } from './assets/EventContext';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Navegação com abas para Tarefas e Calendário
const MainTabs = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === 'Tarefas') {
            iconName = 'list-outline';
          } else if (route.name === 'Calendário') {
            iconName = 'calendar-outline';
          }
          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: 'blue',
        tabBarInactiveTintColor: 'gray',
        headerShown: false, // Oculta o cabeçalho das abas
      })}
    >
      <Tab.Screen name="Tarefas" component={TaskScreen} />
      <Tab.Screen name="Calendário" component={CalendarScreen} />
    </Tab.Navigator>
  );
};

// Fluxo de autenticação
const AuthStack = ({ setIsAuthenticated }) => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Signup" component={SignupScreen} />
      <Stack.Screen name="Login">
        {() => <LoginScreen setIsAuthenticated={setIsAuthenticated} />}
      </Stack.Screen>
    </Stack.Navigator>
  );
};

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <TaskProvider>
      <EventProvider>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {isAuthenticated ? (
              // Após login bem-sucedido, exibe as abas
              <Stack.Screen name="Main" component={MainTabs} />
            ) : (
              // Fluxo de autenticação
              <Stack.Screen name="Auth">
                {() => <AuthStack setIsAuthenticated={setIsAuthenticated} />}
              </Stack.Screen>
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </EventProvider>
    </TaskProvider>
  );
};

export default App;
