import React, { useState } from 'react';
import { TextInput, Alert, TouchableOpacity, Text, SafeAreaView, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LoginScreen = ({ navigation, setIsAuthenticated }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      if (username.trim() === '' || password.trim() === '') {
        Alert.alert('Erro!', 'Preencha os campos para logar.');
        return;
      }

      const usersData = await AsyncStorage.getItem('users');
      const users = usersData ? JSON.parse(usersData) : [];
      const user = users.find(u => u.username === username && u.password === password);

      if (user) {
        Alert.alert('Sucesso!', 'Logado com sucesso!');
        // Atualizar o estado para indicar que o usuário está autenticado
        setIsAuthenticated(true);  // Atualize o estado no App.js
        navigation.navigate('Main');  // Navega para a tela principal
      } else {
        Alert.alert('Erro!', 'Usuário ou senha inválidos.');
      }
    } catch (error) {
      Alert.alert('Erro', 'Falha ao logar.');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Usuário"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

// Definição de estilos para o login
const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', paddingHorizontal: 20, alignItems: 'center' },
  input: { height: 40, borderColor: '#ddd', borderWidth: 1, marginBottom: 20, paddingHorizontal: 10, width: '80%' },
  button: { backgroundColor: '#4CAF50', paddingVertical: 10, paddingHorizontal: 20, borderRadius: 4 },
  buttonText: { color: '#fff', fontWeight: 'bold' },
});

export default LoginScreen;