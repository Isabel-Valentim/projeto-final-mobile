import React, { createContext, useState, useEffect } from 'react';

export const EventContext = createContext();

const API_URL = 'https://6745fc7e512ddbd807fa6e94.mockapi.io/api/events'; // URL do MockAPI

export const EventProvider = ({ children }) => {
  const [eventsByDate, setEventsByDate] = useState({}); // Armazena os eventos organizados por data

  // Função para buscar todos os eventos do MockAPI
  const fetchEvents = async () => {
    try {
      const response = await fetch(API_URL);
      if (!response.ok) {
        throw new Error(`Erro ao buscar eventos: ${response.statusText}`);
      }
      const data = await response.json();

      // Organiza os eventos por data
      const organizedEvents = {};
      data.forEach((event) => {
        if (!organizedEvents[event.eventDate]) {
          organizedEvents[event.eventDate] = [];
        }
        organizedEvents[event.eventDate].push(event);
      });

      setEventsByDate(organizedEvents);
    } catch (error) {
      console.error('Erro ao buscar eventos:', error);
    }
  };

  // Função para adicionar um evento no MockAPI
  const addEvent = async (date, event) => {
    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          eventName: event.name,
          eventDate: date,
          eventLocation: event.location,
          eventDescription: event.description,
        }),
      });

      if (!response.ok) {
        throw new Error(`Erro ao adicionar evento: ${response.statusText}`);
      }

      const createdEvent = await response.json();

      // Atualiza o estado local
      setEventsByDate((prevEvents) => {
        const newEvents = { ...prevEvents };
        if (!newEvents[date]) {
          newEvents[date] = [];
        }
        newEvents[date].push(createdEvent);
        return newEvents;
      });
    } catch (error) {
      console.error('Erro ao adicionar evento:', error);
    }
  };

  // Função para excluir um evento do MockAPI
  const deleteEvent = async (date, eventId) => {
    try {
      const response = await fetch(`${API_URL}/${eventId}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error(`Erro ao excluir evento: ${response.statusText}`);
      }

      // Atualiza o estado local
      setEventsByDate((prevEvents) => {
        const newEvents = { ...prevEvents };
        if (newEvents[date]) {
          newEvents[date] = newEvents[date].filter((event) => event.id !== eventId);
          if (newEvents[date].length === 0) {
            delete newEvents[date];
          }
        }
        return newEvents;
      });
    } catch (error) {
      console.error('Erro ao excluir evento:', error);
    }
  };

  // Busca os eventos ao carregar o componente
  useEffect(() => {
    fetchEvents();
  }, []);

  return (
    <EventContext.Provider value={{ eventsByDate, addEvent, deleteEvent }}>
      {children}
    </EventContext.Provider>
  );
};
