import React, { useState } from 'react';
import { TextInput, Alert, TouchableOpacity, Text, SafeAreaView, StyleSheet } from 'react-native';
import { Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CustomButton = ({ onPress, title }) => (
  <TouchableOpacity onPress={onPress} style={styles.botoes}>
    <Text style={styles.textoBotoes}>{title}</Text>
  </TouchableOpacity>
);

const SignupScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSignup = async () => {
    if (username.trim() === '' || password.trim() === '') {
        Alert.alert('Erro!', 'Usuário e senha não podem estar vazios.');
        return;
    }

    try {
        const existingUsersData = await AsyncStorage.getItem('users');
        const existingUsers = existingUsersData ? JSON.parse(existingUsersData) : [];
        const newUser = { username, password };
        const updatedUsers = [...existingUsers, newUser];

        await AsyncStorage.setItem('users', JSON.stringify(updatedUsers));

        Alert.alert('Successo!', 'Usuário registrado com sucesso!');
        navigation.navigate('Login');
    } catch (error) {
        Alert.alert('Erro!', 'Falha ao registrar usuário.');
      }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Image style={styles.logo} source={require('./carimbofantasy.png')} />
      <Text style={styles.header}>Cadastro</Text>
      <TextInput
        style={styles.input}
        placeholder="Usuário"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <CustomButton title="Cadastrar" onPress={handleSignup} />
      <CustomButton title="Ir para o Login" onPress={() => navigation.navigate('Login')} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  header: {
    paddingBottom: 20,
    fontFamily: 'Calibri',
    fontSize: 26,
    fontWeight: 'bold'
  },
  input: {
    height: 30,
    borderColor: "#AAA",
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 10,
    marginVertical: 10,
    width: '80%'
  },
  botoes: {
    backgroundColor: "#b433ff",
    alignItems: 'center',
    marginVertical: 5,
    borderRadius: 4,
    paddingVertical: 10,
    width: '80%'
  },
  textoBotoes: {
    color: "#FFFFFF",
    fontWeight: 'bold',
    fontFamily: 'Calibri',
    fontSize: 18,
  },
  logo: {
    height: 128,
    width: 128,
    marginBottom: 20
  }
});

export default SignupScreen;