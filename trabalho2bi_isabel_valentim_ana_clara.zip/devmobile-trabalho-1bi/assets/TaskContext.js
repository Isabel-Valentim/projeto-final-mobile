import React, { createContext, useState } from 'react';

export const TaskContext = createContext();

export const TaskProvider = ({ children }) => {
  const [tasksByDate, setTasksByDate] = useState({});

  const addTask = (date, taskText) => {
    setTasksByDate((prevTasks) => {
      const newTasks = { ...prevTasks };
      if (!newTasks[date]) {
        newTasks[date] = [];
      }
      newTasks[date].push(taskText);
      return newTasks;
    });
  };

  const deleteTask = (date, index) => {
    setTasksByDate((prevTasks) => {
      const newTasks = { ...prevTasks };
      if (newTasks[date]) {
        newTasks[date] = newTasks[date].filter((_, i) => i !== index);
        if (newTasks[date].length === 0) {
          delete newTasks[date];
        }
      }
      return newTasks;
    });
  };

  return (
    <TaskContext.Provider value={{ tasksByDate, addTask, deleteTask }}>
      {children}
    </TaskContext.Provider>
  );
};
