import React from 'react';
import { View, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/Ionicons';
import TaskScreen from './TaskScreen';
import CalendarScreen from './CalendarScreen';
import CreateTaskScreen from './CreateTaskScreen';
import CreateEventScreen from './CreateEventScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// Stack Navigator para TaskScreen e CreateTaskScreen
const TaskStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Tarefas" component={TaskScreen} />
      <Stack.Screen name="Criar Tarefa" component={CreateTaskScreen} />
    </Stack.Navigator>
  );
};

const CalendarStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Calendário" component={CalendarScreen}/>
      <Stack.Screen name="Criar Evento" component={CreateEventScreen}/>
    </Stack.Navigator>
  )
}

// Tab Navigator com TaskStack no lugar de TaskScreen
const HomeTabs = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarActiveTintColor: 'blue',
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: { backgroundColor: '#f8f9fa' },
        headerShown: false,
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === 'Tarefas') {
            iconName = 'list-outline'; // Ícone para Tasks
          } else if (route.name === 'Calendário') {
            iconName = 'calendar-outline'; // Ícone para Calendar
          }
          return <Icon name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Tarefas" component={TaskStack} />
      <Tab.Screen name="Calendário" component={CalendarStack} />
    </Tab.Navigator>
  );
};

// HomeScreen contendo o Tab Navigator
const HomeScreen = () => {
  return (
    <View style={styles.container}>
      <View style={styles.tabsContainer}>
        <HomeTabs />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabsContainer: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
});

export default HomeScreen;
