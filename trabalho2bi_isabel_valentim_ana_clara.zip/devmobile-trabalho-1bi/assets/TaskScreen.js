import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { Calendar } from 'react-native-calendars';

const API_URL = 'https://6745fc7e512ddbd807fa6e94.mockapi.io/api/tasks';

const TaskScreen = () => {
  const [tasks, setTasks] = useState([]); // Estado para tarefas
  const [newTask, setNewTask] = useState(''); // Estado para nova tarefa
  const [selectedDate, setSelectedDate] = useState(''); // Estado para a data selecionada

  // Função para buscar tarefas da MockAPI
  const fetchTasks = async () => {
    try {
      const response = await fetch(API_URL);
      if (!response.ok) {
        throw new Error(`Erro ao buscar tarefas: ${response.statusText}`);
      }
      const data = await response.json();
      setTasks(data);
    } catch (error) {
      console.error('Erro ao buscar tarefas:', error);
      Alert.alert('Erro', 'Não foi possível carregar as tarefas.');
    }
  };

  // Função para adicionar uma nova tarefa associada à data selecionada
  const addTask = async () => {
    if (!newTask.trim()) {
      Alert.alert('Erro', 'A tarefa não pode estar vazia.');
      return;
    }

    if (!selectedDate) {
      Alert.alert('Erro', 'Selecione uma data para a tarefa.');
      return;
    }

    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ task: newTask, date: selectedDate }),
      });

      if (!response.ok) {
        throw new Error(`Erro ao adicionar tarefa: ${response.statusText}`);
      }

      const createdTask = await response.json();
      setTasks((prevTasks) => [...prevTasks, createdTask]);
      setNewTask('');
      Alert.alert('Sucesso', 'Tarefa adicionada com sucesso.');
    } catch (error) {
      console.error('Erro ao adicionar tarefa:', error);
      Alert.alert('Erro', 'Não foi possível adicionar a tarefa.');
    }
  };

  // Função para excluir uma tarefa
  const deleteTask = async (id) => {
    try {
      const response = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
      if (!response.ok) {
        throw new Error(`Erro ao excluir tarefa: ${response.statusText}`);
      }

      setTasks((prevTasks) => prevTasks.filter((task) => task.id !== id));
      Alert.alert('Sucesso', 'Tarefa excluída com sucesso.');
    } catch (error) {
      console.error('Erro ao excluir tarefa:', error);
      Alert.alert('Erro', 'Não foi possível excluir a tarefa.');
    }
  };

  // Carrega as tarefas ao montar o componente
  useEffect(() => {
    fetchTasks();
  }, []);

  // Renderiza cada item da lista de tarefas
  const renderTask = ({ item }) => (
    <View style={styles.taskContainer}>
      <Text style={styles.taskText}>
        {item.date}: {item.task}
      </Text>
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => deleteTask(item.id)}
      >
        <Text style={styles.deleteButtonText}>Excluir</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tarefas</Text>
      <Calendar
        onDayPress={(day) => setSelectedDate(day.dateString)} // Seleciona a data
        markedDates={{
          [selectedDate]: { selected: true, selectedColor: '#00adf5' },
        }}
        style={styles.calendar}
      />
      <Text style={styles.selectedDate}>
        Data selecionada: {selectedDate || 'Nenhuma'}
      </Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Digite uma nova tarefa"
          value={newTask}
          onChangeText={setNewTask}
        />
        <TouchableOpacity style={styles.addButton} onPress={addTask}>
          <Text style={styles.addButtonText}>Adicionar</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={tasks.filter((task) => task.date === selectedDate)} // Filtra tarefas pela data selecionada
        keyExtractor={(item) => item.id}
        renderItem={renderTask}
        ListEmptyComponent={
          <Text style={styles.noTasksText}>Nenhuma tarefa encontrada para esta data</Text>
        }
      />
    </View>
  );
};

export default TaskScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  calendar: {
    marginBottom: 20,
  },
  selectedDate: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 20,
    alignItems: 'center',
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: 10,
    marginRight: 10,
  },
  addButton: {
    backgroundColor: '#00adf5',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  addButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  taskContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    marginBottom: 10,
  },
  taskText: {
    fontSize: 16,
    flex: 1,
  },
  deleteButton: {
    backgroundColor: '#f00',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  deleteButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  noTasksText: {
    fontSize: 16,
    textAlign: 'center',
    color: '#999',
  },
});
