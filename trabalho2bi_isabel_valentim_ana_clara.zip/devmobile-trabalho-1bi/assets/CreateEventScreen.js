import React, { useEffect, useState } from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  Alert,
  TouchableOpacity,
  Text,
  FlatList,
} from 'react-native';
import { Calendar } from 'react-native-calendars';

const API_URL = 'https://6745fc7e512ddbd807fa6e94.mockapi.io/api/events';

const EventScreen = () => {
  const [selectedDate, setSelectedDate] = useState(''); // Data selecionada
  const [eventDetails, setEventDetails] = useState({
    name: '',
    location: '',
    description: '',
  });
  const [events, setEvents] = useState([]); // Lista de eventos da API

  // Função para buscar eventos do MockAPI
  const fetchEvents = async () => {
    try {
      const response = await fetch(API_URL);
      if (!response.ok) {
        throw new Error(`Erro ao buscar eventos: ${response.statusText}`);
      }
      const data = await response.json();
      setEvents(data); // Atualiza o estado com os eventos
    } catch (error) {
      console.error('Erro ao buscar eventos:', error);
      Alert.alert('Erro', 'Não foi possível carregar os eventos.');
    }
  };

  // Função para adicionar um evento
  const handleAddEvent = async () => {
    if (!selectedDate || !eventDetails.name.trim() || !eventDetails.location.trim() || !eventDetails.description.trim()) {
      Alert.alert('Erro', 'Todos os campos devem ser preenchidos.');
      return;
    }

    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          eventName: eventDetails.name,
          eventDate: selectedDate,
          eventLocation: eventDetails.location,
          eventDescription: eventDetails.description,
        }),
      });

      if (!response.ok) {
        throw new Error(`Erro ao adicionar evento: ${response.statusText}`);
      }

      const createdEvent = await response.json();
      setEvents((prevEvents) => [...prevEvents, createdEvent]); // Adiciona ao estado local
      setEventDetails({ name: '', location: '', description: '' }); // Reseta os campos
      Alert.alert('Sucesso', 'Evento adicionado com sucesso!');
    } catch (error) {
      console.error('Erro ao adicionar evento:', error);
      Alert.alert('Erro', 'Não foi possível adicionar o evento.');
    }
  };

  // Função para excluir um evento
  const handleDeleteEvent = async (id) => {
    try {
      const response = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
      if (!response.ok) {
        throw new Error(`Erro ao excluir evento: ${response.statusText}`);
      }

      setEvents((prevEvents) => prevEvents.filter((event) => event.id !== id)); // Remove do estado local
      Alert.alert('Sucesso', 'Evento excluído com sucesso!');
    } catch (error) {
      console.error('Erro ao excluir evento:', error);
      Alert.alert('Erro', 'Não foi possível excluir o evento.');
    }
  };

  // Carrega os eventos ao montar o componente
  useEffect(() => {
    fetchEvents();
  }, []);

  // Renderiza cada item da lista de eventos
  const renderEvent = ({ item }) => (
    <View style={styles.eventContainer}>
      <Text style={styles.eventText}>
        <Text style={styles.label}>Data:</Text> {item.eventDate}
      </Text>
      <Text style={styles.eventText}>
        <Text style={styles.label}>Nome:</Text> {item.eventName}
      </Text>
      <Text style={styles.eventText}>
        <Text style={styles.label}>Local:</Text> {item.eventLocation}
      </Text>
      <Text style={styles.eventText}>
        <Text style={styles.label}>Descrição:</Text> {item.eventDescription}
      </Text>
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => handleDeleteEvent(item.id)} // Excluir evento
      >
        <Text style={styles.deleteButtonText}>Excluir</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Eventos</Text>
      <Calendar
        onDayPress={(day) => setSelectedDate(day.dateString)} // Seleciona a data
        markedDates={{
          [selectedDate]: { selected: true, selectedColor: '#00adf5' },
        }}
        style={styles.calendar}
      />
      <Text style={styles.selectedDate}>
        Data selecionada: {selectedDate || 'Nenhuma'}
      </Text>
      <TextInput
        style={styles.input}
        placeholder="Nome do Evento"
        value={eventDetails.name}
        onChangeText={(text) =>
          setEventDetails((prev) => ({ ...prev, name: text }))
        }
      />
      <TextInput
        style={styles.input}
        placeholder="Local do Evento"
        value={eventDetails.location}
        onChangeText={(text) =>
          setEventDetails((prev) => ({ ...prev, location: text }))
        }
      />
      <TextInput
        style={styles.input}
        placeholder="Descrição do Evento"
        value={eventDetails.description}
        onChangeText={(text) =>
          setEventDetails((prev) => ({ ...prev, description: text }))
        }
      />
      <TouchableOpacity style={styles.addButton} onPress={handleAddEvent}>
        <Text style={styles.addButtonText}>Adicionar Evento</Text>
      </TouchableOpacity>
      <FlatList
        data={events.filter((event) => event.eventDate === selectedDate)} // Filtra eventos pela data selecionada
        keyExtractor={(item) => item.id}
        renderItem={renderEvent}
        ListEmptyComponent={
          <Text style={styles.noEventsText}>Nenhum evento para esta data</Text>
        }
      />
    </View>
  );
};

export default EventScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  calendar: {
    marginBottom: 20,
  },
  selectedDate: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  addButton: {
    backgroundColor: '#00adf5',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 20,
  },
  addButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  eventContainer: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    marginBottom: 10,
  },
  eventText: {
    fontSize: 16,
    marginBottom: 5,
  },
  label: {
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: '#f00',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
    alignSelf: 'flex-start',
  },
  deleteButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  noEventsText: {
    fontSize: 16,
    textAlign: 'center',
    color: '#999',
  },
});
