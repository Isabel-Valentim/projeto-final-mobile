import React, { useContext, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Alert,
} from 'react-native';
import { Calendar } from 'react-native-calendars';
import { EventContext } from './EventContext';

const CalendarScreen = () => {
  const { eventsByDate, addEvent, deleteEvent } = useContext(EventContext); // Obtém os eventos e métodos do contexto
  const [selectedDate, setSelectedDate] = useState('');
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');

  // Função para adicionar um novo evento
  const handleAddEvent = () => {
    if (!selectedDate) {
      Alert.alert('Erro', 'Por favor, selecione uma data no calendário.');
      return;
    }
    if (!name.trim() || !location.trim() || !description.trim()) {
      Alert.alert('Erro', 'Preencha todos os campos para adicionar um evento.');
      return;
    }
    const event = { name, location, description };
    addEvent(selectedDate, event);
    setName('');
    setLocation('');
    setDescription('');
    Alert.alert('Sucesso', 'Evento adicionado!');
  };

  // Função para excluir um evento
  const handleDeleteEvent = (date, eventId) => {
    deleteEvent(date, eventId);
    Alert.alert('Sucesso', 'Evento excluído!');
  };

  // Renderiza cada evento com botão de exclusão
  const renderEvent = ({ item }) => (
    <View style={styles.eventContainer}>
      <Text style={styles.eventText}>Nome: {item.eventName}</Text>
      <Text style={styles.eventText}>Local: {item.eventLocation}</Text>
      <Text style={styles.eventText}>Descrição: {item.eventDescription}</Text>
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => handleDeleteEvent(item.eventDate, item.id)}
      >
        <Text style={styles.deleteButtonText}>Excluir</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calendário</Text>
      <Calendar
        onDayPress={(day) => setSelectedDate(day.dateString)}
        markedDates={{
          [selectedDate]: {
            selected: true,
            selectedColor: '#00adf5',
          },
        }}
      />
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Nome do Evento"
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.input}
          placeholder="Local do Evento"
          value={location}
          onChangeText={setLocation}
        />
        <TextInput
          style={styles.input}
          placeholder="Descrição do Evento"
          value={description}
          onChangeText={setDescription}
        />
        <TouchableOpacity style={styles.addButton} onPress={handleAddEvent}>
          <Text style={styles.addButtonText}>Adicionar Evento</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.selectedDate}>
        Data selecionada: {selectedDate || 'Nenhuma data selecionada'}
      </Text>
      <View style={styles.eventsContainer}>
        {selectedDate && eventsByDate[selectedDate] ? (
          <FlatList
            data={eventsByDate[selectedDate]}
            renderItem={renderEvent}
            keyExtractor={(item) => item.id}
          />
        ) : (
          <Text style={styles.noEventsText}>
            Nenhum evento encontrado para a data selecionada
          </Text>
        )}
      </View>
    </View>
  );
};

export default CalendarScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  inputContainer: {
    marginTop: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  addButton: {
    backgroundColor: '#00adf5',
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 20,
  },
  addButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  selectedDate: {
    fontSize: 16,
    marginTop: 20,
    textAlign: 'center',
  },
  eventsContainer: {
    marginTop: 20,
  },
  eventContainer: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    marginBottom: 10,
    backgroundColor: '#f9f9f9',
  },
  eventText: {
    fontSize: 16,
  },
  deleteButton: {
    backgroundColor: '#f00',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
    marginTop: 10,
    alignSelf: 'flex-start',
  },
  deleteButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  noEventsText: {
    fontSize: 16,
    textAlign: 'center',
    color: '#999',
  },
});
