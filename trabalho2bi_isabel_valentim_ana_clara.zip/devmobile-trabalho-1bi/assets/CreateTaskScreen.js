import React, { useState, useContext } from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  Text,
  Alert,
  TouchableOpacity,
} from 'react-native';
import { Calendar } from 'react-native-calendars';
import { TaskContext } from './TaskContext';

const CreateTaskScreen = ({ navigation }) => {
  const { addTask } = useContext(TaskContext); // Obtém a função de adicionar tarefas do contexto
  const [taskText, setTaskText] = useState('');
  const [selectedDate, setSelectedDate] = useState('');

  const handleAddTask = () => {
    if (!taskText.trim()) {
      Alert.alert('Erro', 'A tarefa não pode estar vazia');
      return;
    }
    if (!selectedDate) {
      Alert.alert('Erro', 'Por favor, selecione uma data para a tarefa');
      return;
    }

    addTask(selectedDate, taskText); // Adiciona a tarefa no contexto
    setTaskText('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Criar Tarefa</Text>
      <Calendar
        onDayPress={(day) => setSelectedDate(day.dateString)}
        markedDates={{
          [selectedDate]: {
            selected: true,
            selectedColor: '#00adf5',
          },
        }}
      />
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Digite uma tarefa"
          value={taskText}
          onChangeText={setTaskText}
        />
        <TouchableOpacity style={styles.addButton} onPress={handleAddTask}>
          <Text style={styles.addButtonText}>Adicionar</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.selectedDate}>
        Data selecionada: {selectedDate || 'Nenhuma data selecionada'}
      </Text>
    </View>
  );
};

export default CreateTaskScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#cccccc',
    borderRadius: 5,
    padding: 10,
    marginRight: 10,
  },
  addButton: {
    backgroundColor: '#00adf5',
    padding: 10,
    borderRadius: 5,
  },
  addButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  selectedDate: {
    fontSize: 16,
    marginTop: 20,
    textAlign: 'center',
  },
});